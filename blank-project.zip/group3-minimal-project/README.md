# Group 3 Minimal Project Structure
